// cloudfunctions/joinRoom/index.js
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const _ = db.command;

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID;

  const { roomId, nickname, avatar, unit } = event || {};
  if (!roomId) return { ok: false, message: 'roomId required' };

  const roomRef = db.collection('rooms').doc(roomId);

  // 1) 尝试读房间
  try {
    const roomRes = await roomRef.get();
    const room = roomRes.data || {};
    const users = Array.isArray(room.users) ? room.users : [];

    const exists = users.some(u => u && u.openid === openid);

    if (!exists) {
      await roomRef.update({
        data: {
          users: _.push({
            openid,
            nickname: nickname || ('酒友' + openid.slice(-4)),
            avatar: avatar || '',
            createdAt: db.serverDate(),
          })
        }
      });
    } else {
      // 如果存在，允许更新昵称头像（可选）
      const newNick = nickname || null;
      const newAvatar = avatar || null;

      // 这里为了简单不做数组内精确更新，交给前端 room.js 的 updateMyProfile 来做
      // 你也可以在这里实现数组更新逻辑
      void newNick; void newAvatar;
    }

    // 如果房间没 unit，补一下
    if (!room.unit) {
      await roomRef.update({ data: { unit: unit || '杯' } });
    }

    return { ok: true, openid };
  } catch (e) {
    // 2) 房间不存在，创建
    await db.collection('rooms').add({
      data: {
        _id: roomId,
        unit: unit || '杯',
        users: [{
          openid,
          nickname: nickname || '房主',
          avatar: avatar || '',
          createdAt: db.serverDate(),
        }],
        createdAt: db.serverDate(),
      }
    });

    return { ok: true, openid, created: true };
  }
};