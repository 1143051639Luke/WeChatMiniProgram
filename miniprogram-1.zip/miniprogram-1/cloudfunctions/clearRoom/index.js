// cloudfunctions/clearRoom/index.js
const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

exports.main = async (event, context) => {
  const { roomId } = event;
  
  // 安全检查：如果没有房间号，就不执行
  if (!roomId) return { success: false, msg: 'No roomId' };

  try {
    // 🔥 核心操作：删除 transactions 表里，属于这个房间的所有记录
    await db.collection('transactions').where({
      roomId: roomId
    }).remove();

    return { success: true };
  } catch (e) {
    console.error(e);
    return { success: false, error: e };
  }
};